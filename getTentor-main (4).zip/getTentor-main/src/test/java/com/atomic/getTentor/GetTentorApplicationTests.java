package com.atomic.getTentor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetTentorApplicationTests {

	@Test
	void contextLoads() {
	}

}
