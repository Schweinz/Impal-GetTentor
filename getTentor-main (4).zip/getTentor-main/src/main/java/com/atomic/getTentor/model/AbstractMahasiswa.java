package com.atomic.getTentor.model;

public abstract class AbstractMahasiswa {
    public abstract Integer getId(); // atau UUID
    public abstract String getEmail();
    public abstract String getNama();
    public abstract String getRole();
    public abstract String getFotoUrl();
    public abstract  String getNoTelp();
}
