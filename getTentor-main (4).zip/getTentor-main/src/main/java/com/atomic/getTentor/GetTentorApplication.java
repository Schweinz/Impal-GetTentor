package com.atomic.getTentor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetTentorApplication {
	public static void main(String[] args) {
		SpringApplication.run(GetTentorApplication.class, args);
	}
}
