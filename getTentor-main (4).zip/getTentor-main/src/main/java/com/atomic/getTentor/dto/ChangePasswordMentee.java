package com.atomic.getTentor.dto;

public record ChangePasswordMentee(String password, String repeatPassword) {

}
