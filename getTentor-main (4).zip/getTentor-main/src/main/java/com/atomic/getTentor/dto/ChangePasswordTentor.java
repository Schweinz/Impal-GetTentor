package com.atomic.getTentor.dto;

public record ChangePasswordTentor(String password, String repeatPassword) {
    
}
