package com.atomic.getTentor.model;

public enum VerificationStatus {
    PENDING, APPROVED, REJECTED, SUSPENDED
}
